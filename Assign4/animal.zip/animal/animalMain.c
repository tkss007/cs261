//
//  animalMain.c
//  animal
//


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "animal.h"


int main(){
    

    char temp;
    FILE *f;
    f = fopen("animal.txt","r");
    assert(f != 0);
    struct BSTree *animalTree = createAnimalTree(f);
    
    printf("Animal Gaming!!!\n\n");
    beginAnimalGame(animalTree);
    while (!isEnd()){
        if ((temp = fgetc(stdin)) != 0) {
            if (temp == 'Y' || temp == 'y') {
                answerYes();
            }
            else if(temp == 'N' || temp == 'n'){
                answerNo();
            }
        }
    }
    
    return 1;
}