//
//  animal.h
//  animal
//

#include <stdio.h>
#include "bst.h"
#ifndef animal_animal_h
#define animal_animal_h


#endif
struct BSTree *createAnimalTree(FILE *f);

void beginAnimalGame(struct BSTree *tree);
void answerYes();
void answerNo();
void askAgain();
int isEnd();
