/*
 File: animal.c
 Implementation of animal game.
 
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "bst.h"
#include "structs.h"
#include "animal.h"


struct BSTree *createAnimalTree(FILE *f){
    struct BSTree *tree = newBSTree();
    
    char *buffer;
    char Qnum[3];
    struct animal *aml;
    
    while (fgets(Qnum,3,f) != 0) {
        buffer = (char *)malloc(sizeof(char )*100);
        aml = (struct animal *)malloc(sizeof(struct animal));
        fgets(buffer, 100, f);
        aml->number = atoi(Qnum);
        aml->words = buffer;
        addBSTree(tree, aml);
        
    }
    return tree;
}



